'use client'

import { useEffect, useState } from 'react'
import { useEvents } from '@/hooks/useEvents'
import { useAuth } from '@/hooks/useAuth'
import { isEventEnded } from '@/lib/eventTiming'
import HeroSection from '@/components/layout/HeroSection'
import WhyDiceSection from '@/components/layout/WhyDiceSection'
import FormationsSection from '@/components/layout/FormationsSection'
import CTASection from '@/components/layout/CTASection'
import ReservationModal from '@/components/events/ReservationModal'
import toast from 'react-hot-toast'

export default function Home() {
  const { events, loading, fetchPublicEvents } = useEvents()
  const { isAuthenticated } = useAuth()
  const [selectedEvent, setSelectedEvent] = useState(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  useEffect(() => {
    fetchPublicEvents?.()
  }, [fetchPublicEvents])

  const upcomingEvents = (events || [])
    .filter((e: any) => {
      if (e.status && e.status !== 'published') return false
      return !isEventEnded(e)
    })
    .sort(
      (a: any, b: any) =>
        new Date(a.start_date || 0).getTime() -
        new Date(b.start_date || 0).getTime()
    )
    .slice(0, 3)

  const openReservation = (event: any) => {
    if (!isAuthenticated) {
      toast.error('Veuillez vous connecter pour réserver')
      return
    }
    setSelectedEvent(event)
    setIsModalOpen(true)
  }

  return (
    <div className="min-h-screen bg-[#F4F7FB]">
      <HeroSection />
      <WhyDiceSection />
      <FormationsSection
        events={upcomingEvents}
        loading={loading}
        onReserve={openReservation}
      />
      <CTASection />

      <ReservationModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false)
          setSelectedEvent(null)
        }}
        event={selectedEvent}
        onSuccess={(ticket: any) => {
          const qty = Math.max(1, Number(ticket?.quantity ?? 1))
          toast.success(
            `${qty} ticket${qty > 1 ? 's' : ''} réservé${qty > 1 ? 's' : ''} ! Retrouvez-les dans Mon espace.`
          )
          fetchPublicEvents?.()
        }}
      />
    </div>
  )
}
